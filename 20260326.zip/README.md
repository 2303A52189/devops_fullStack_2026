# Terraform Scalable Infrastructure Project

## Steps to Run

1. Install Terraform
2. Configure AWS CLI:
   aws configure

3. Initialize Terraform:
   terraform init

4. Plan:
   terraform plan

5. Apply:
   terraform apply

## Notes
- Change instance_count in terraform.tfvars to scale
- Use terraform workspace for dev/prod