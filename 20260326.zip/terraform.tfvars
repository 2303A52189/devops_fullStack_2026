ami_id = "ami-0abcdef12345"
instance_count = 2